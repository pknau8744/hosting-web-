const form = document.getElementById("dataForm");
const responseMsg = document.getElementById("responseMsg");
const dataTableBody = document.querySelector("#dataTable tbody");
const cancelEditBtn = document.getElementById("cancelEdit");

let editId = null; // currently editing document ID

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const formData = new FormData(form);
  const data = {};
  formData.forEach((value, key) => {
    if(key === "mo") data[key] = Number(value);
    else if(key === "id") return; // skip hidden id field in normal submit
    else data[key] = value;
  });

  try {
    let response;
    if(editId) {
      // Edit mode - PATCH
      response = await fetch(`/update/${editId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
    } else {
      // Create mode - POST
      response = await fetch("/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
    }

    if(!response.ok) throw new Error("Request failed");

    const result = await response.json();
    responseMsg.textContent = result.message;
    form.reset();
    editId = null;
    cancelEditBtn.style.display = "none";
    loadData();
  } catch (err) {
    responseMsg.textContent = "❌ Operation failed!";
    console.error(err);
  }
});

cancelEditBtn.addEventListener("click", () => {
  editId = null;
  form.reset();
  cancelEditBtn.style.display = "none";
  responseMsg.textContent = "";
});

async function loadData() {
  try {
    const res = await fetch("/getSavedData");
    if(!res.ok) throw new Error("Failed to fetch data");
    const result = await res.json();

    if(Array.isArray(result.savedData)) {
      dataTableBody.innerHTML = "";
      result.savedData.forEach(item => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
          <td>${item.name}</td>
          <td>${item.servesh}</td>
          <td>${item.city}</td>
          <td>${item.cost}</td>
          <td>${item.iss}</td>
          <td>${item.mo}</td>
          <td>
            <button class="edit" data-id="${item._id}">Edit</button>
            <button class="delete" data-id="${item._id}">Delete</button>
          </td>
        `;

        dataTableBody.appendChild(tr);
      });

      // Add event listeners to new buttons
      document.querySelectorAll("button.edit").forEach(btn => {
        btn.onclick = () => startEdit(btn.dataset.id);
      });

      document.querySelectorAll("button.delete").forEach(btn => {
        btn.onclick = () => deleteData(btn.dataset.id);
      });
    }
  } catch (err) {
    console.error("Error loading data:", err);
  }
}

async function startEdit(id) {
  try {
    const res = await fetch("/getSavedData");
    const result = await res.json();
    const item = result.savedData.find(d => d._id === id);
    if (!item) throw new Error("Data not found");

    editId = id;
    form.name.value = item.name;
    form.servesh.value = item.servesh;
    form.city.value = item.city;
    form.cost.value = item.cost;
    form.iss.value = item.iss;
    form.mo.value = item.mo;
    cancelEditBtn.style.display = "inline-block";
    responseMsg.textContent = "Editing mode: Update data and submit";
  } catch (err) {
    console.error(err);
  }
}

async function deleteData(id) {
  if(!confirm("Are you sure you want to delete this entry?")) return;

  try {
    const res = await fetch(`/delete/${id}`, { method: "DELETE" });
    if(!res.ok) throw new Error("Delete failed");
    const result = await res.json();
    responseMsg.textContent = result.message;
    loadData();
  } catch (err) {
    responseMsg.textContent = "❌ Delete failed!";
    console.error(err);
  }
}


